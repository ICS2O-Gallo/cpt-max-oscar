import pygame
pygame.font.init()
# for fonts: https://coderslegacy.com/python/pygame-font/ 
from pygame.locals import K_ESCAPE, KEYDOWN, QUIT, MOUSEBUTTONDOWN, MOUSEBUTTONUP
import math
import random
import time

pygame.init()

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 225)
GREY = (146, 160, 173)
ORANGE = (206, 120, 11)
LIGHT_YELLOW = (242, 238, 208)
CAMERA_GREEN = (0, 255, 187)
CAMERA_YELLOW = (255, 217, 0)
SPACE_BLUE = (44, 3, 252)
PURPLE = (149, 0, 255)
PI = math.pi
bulb_color = BLACK
opacity = 50
opacity_2 = 200
radius = 1
light_bulb_part = True
instruction_part = False
camera_part = False
key_part = False
frame = 0
time = 0

first_time = 0
start_radius = 0
font = pygame.font.SysFont('verdana', 20)

def draw_battery(screen, x, y, length, width):
    pygame.draw.rect(screen, GREY, [x, y, length, width])
    pygame.draw.polygon(screen, ORANGE, [[x,y], [x+2/5*length,y], [x+3/5*length,y+width], [x,y+width]])
    pygame.draw.rect(screen, GREY, [x+length,y+1/5*width,0.1*length,0.6*width])
    

def draw_lightbulb(screen, x, y, opacity):
    pygame.draw.rect(screen, LIGHT_YELLOW, [x, y, 200, 100])
    for i in range (x, x+100, 20):
        pygame.draw.line(screen, BLACK, [x,y+i-x], [x+200,y+i-x],10)
    draw_rect_alpha(screen, (153, 208, 255, opacity), [x,y+100,200,150])
    draw_circle_alpha(screen, (153,208,255,opacity),[x+100,y+362],150)
    pygame.draw.line(screen, bulb_color, [x+100, y+250],[x+30,y+350],7)
    pygame.draw.line(screen, bulb_color, [x+170, y+400],[x+30,y+350],7)
    pygame.draw.line(screen, bulb_color, [x+170, y+400],[x+50,y+430],7)
    pygame.draw.line(screen, bulb_color, [x+150, y+470],[x+50,y+430],7)
    pygame.draw.line(screen, bulb_color, [x+150, y+470],[x+70,y+490],7)

def draw_rect_alpha(surface, color, rect):
    shape_surf = pygame.Surface(pygame.Rect(rect).size, pygame.SRCALPHA)
    pygame.draw.rect(shape_surf, color, shape_surf.get_rect())
    surface.blit(shape_surf, rect)

def draw_circle_alpha(surface, color, center, radius):
    target_rect = pygame.Rect(center, (0, 0)).inflate((radius * 2, radius * 2))
    shape_surf = pygame.Surface(target_rect.size, pygame.SRCALPHA)
    pygame.draw.circle(shape_surf, color, (radius, radius), radius)
    surface.blit(shape_surf, target_rect)

def draw_circuit(screen, x, y, list):
    pygame.draw.rect(screen, WHITE, [x, y, 450, 450], 10)
    pygame.draw.line(screen, list[1], [x+100,y+350],[x+50,y+350],5)
    pygame.draw.line(screen, list[1], [x+50,y+350],[x+50,y+50],5)
    pygame.draw.line(screen, list[2], [x+50,y+50],[x+150,y+50],5)
    pygame.draw.line(screen, list[3], [x+150,y+50],[x+150,y+250],5)
    pygame.draw.line(screen, list[4], [x+250,y+250],[x+150,y+250],5)
    pygame.draw.line(screen, list[5], [x+250,y+250],[x+250,y+70],5)
    pygame.draw.line(screen, list[6], [x+300,y+70],[x+250,y+70],5)
    pygame.draw.line(screen, list[7], [x+300,y+70],[x+300,y+200],5)
    pygame.draw.line(screen, list[8], [x+350,y+200],[x+300,y+200],5)
    pygame.draw.line(screen, list[9], [x+350,y+200],[x+350,y+100],5)
    pygame.draw.line(screen, list[10], [x+175,y+100],[x+350,y+100],5)
    pygame.draw.line(screen, list[11], [x+175,y+100],[x+175,y+30],5)
    pygame.draw.line(screen, list[12], [x+400,y+30],[x+175,y+30],5)
    pygame.draw.line(screen, list[13], [x+400,y+30],[x+400,260],5)
    pygame.draw.line(screen, list[14], [800,260],[x+400,260],5)
    pygame.draw.line(screen, list[15], [800,260],[1100,260],5)
    pygame.draw.line(screen, list[16], [1100,260],[1100,150],5)
    pygame.draw.line(screen, list[17], [570,150],[1100,150],5)
    pygame.draw.line(screen, list[18], [570,150],[570,y+350],5)
    pygame.draw.line(screen, list[18], [x+350,y+350],[570,y+350],5)
    draw_battery(screen,x+100,y+300,250,100)
    
def draw_camera(screen, x, y, radius):
    pygame.draw.rect(screen, WHITE, [x,y,1000,500])
    pygame.draw.rect(screen, CAMERA_GREEN, [x,y+50,1000,400])
    pygame.draw.rect(screen, CAMERA_GREEN, [x+30,y-50,150,50])
    pygame.draw.polygon(screen, CAMERA_GREEN, [[x+300,y],[x+700,y],[x+600,y-50],[x+400,y-50]])
    pygame.draw.rect(screen, CAMERA_GREEN, [x+820,y-50,150,50])
    pygame.draw.rect(screen, WHITE, [x+450,y-40,100,30])
    pygame.draw.rect(screen, WHITE, [x+800,y+150,150,50])
    pygame.draw.circle(screen, CAMERA_YELLOW, [x+500,y+250], 230)
    pygame.draw.circle(screen, BLACK, [x+500,y+250], radius)
    pygame.draw.circle(screen, BLUE, [x+890,y+340], 80)
    instruction = font.render("CLICK HERE", True, WHITE)
    screen.blit(instruction, [x+830, y+340])

def draw_key(screen, x, y, color):
    pygame.draw.circle(screen, color, [x, y], 100)
    pygame.draw.rect(screen, color, [x+90, y-20, 180, 40])
    pygame.draw.rect(screen, color, [x+140, y+20, 20, 30])
    pygame.draw.rect(screen, color, [x+200, y+20, 20, 30])

def distance(x, y):
    center_x = x + 135/2
    center_y = y + 75/2
    distance = math.sqrt((640-center_x)**2 + (335-center_y)**2)
    return distance
    
WIDTH = 1280
HEIGHT = 720
SIZE = (WIDTH, HEIGHT)
window = pygame.display.set_mode(SIZE)
clock = pygame.time.Clock()
button_click = 0
button = pygame.Rect(1030,350,200,200)
click = 0
position = [-100, 0]
rect_x = 0
rect_y = 0
points = 0
ufo_list = []

image = pygame.image.load("among_us.png").convert_alpha()
ufo = pygame.image.load("ufos (2).jpg").convert()
ufo.set_colorkey(BLACK)
ufo_2 = pygame.image.load("ufos (3).jpg").convert()
ufo_2.set_colorkey(BLACK)
pygame.display.set_caption("Oscar's room")

start_ticks=pygame.time.get_ticks()

running = True

# ---------------------------
while running:
    if light_bulb_part:
        seconds = round(pygame.time.get_ticks() - start_ticks / 1000)
        wire_color = [GREY] * 20
        for event in pygame.event.get():
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    running = False
            elif event.type == QUIT:
                running = False
            elif event.type == MOUSEBUTTONDOWN:
                mouse_x, mouse_y = event.pos
                distance = math.sqrt((mouse_x-1130) ** 2 + (mouse_y-450) ** 2)
                if distance <= 100:
                    click = 1
                else:
                    click = 0
                    button_click = 0
            elif event.type == MOUSEBUTTONUP:
                click = 0
        
        button_click += click
        for i in range (0, 20):
            if button_click > 50 * i:
                for j in range(0, i):
                    wire_color[i] = WHITE
                if i == 14:
                    bulb_color = WHITE


        if click == 0:
            bulb_color = BLACK
            opacity = 50
        
        
        window.fill(BLACK)

        if bulb_color == WHITE:
            if opacity < 250:
                opacity += 1
            draw_circle_alpha(window, (242, 238, 208, opacity_2), [800,372], 150+radius)
            radius += 10
            if opacity_2 >= 10:
                opacity_2 -= 5
            else:
                radius = 1
                opacity_2 = 200
            if radius >= 150:
                draw_circle_alpha(window, (242, 238, 208, opacity_2), [800,372], 20+radius)
        draw_lightbulb(window, 700, 10, opacity)
        draw_circuit(window, 20, 20, wire_color)
        pygame.draw.circle(window, RED, [1130, 450],100)

        font_1 = pygame.font.SysFont("verdana", 20, True, True)
        instruction_1 = font_1.render("The light bulb in this room is disconnected from electricity.", True, WHITE)
        window.blit(instruction_1, [10, 500])
        instruction_2 = font_1.render("You need to reconnect electricity and make it shine", True, WHITE)
        window.blit(instruction_2, [10, 530])
        instruction_4 = font_1.render("before you see what's inside this room.", True, WHITE)
        window.blit(instruction_4, [10, 560])
        instruction_3 = font_1.render("CLICK HERE", True, BLACK)
        window.blit(instruction_3, [1070,450])

        if wire_color[19] == WHITE:
            light_bulb_part = False
            instruction_part = True

    if instruction_part:
        time += 1
        window.fill(LIGHT_YELLOW)
        font_1 = pygame.font.SysFont("verdana", 30, False, True)
        instruction_1 = font_1.render("Congratulations, you've turned on the light bulb!", True, BLACK)
        instruction_2 = font_1.render("Now see what's inside this room", True, BLACK)
        instruction_3 = font_1.render("You need to use the camera to capture UFO and get 150 points", True, BLACK)
        instruction_4 = font_1.render("Once you've done the task, collect one key leading to the final room", True, BLACK)
        window.blit(instruction_1, [300, 200])
        window.blit(instruction_2, [300, 250])
        window.blit(instruction_3, [300, 300])
        window.blit(instruction_4, [300, 350])
        window.blit(image, position)
        if time == 300:
            instruction_part = False
            camera_part = True
            time = 0


    if camera_part:
        for event in pygame.event.get():
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    running = False
            elif event.type == QUIT:
                running = False
            elif event.type == MOUSEBUTTONDOWN:
                mouse_x, mouse_y = event.pos
                distance = math.sqrt((mouse_x-1030) ** 2 + (mouse_y-425) ** 2)
                center_x = rect_x + 135/2
                center_y = rect_y + 75/2
                ufo_camera = math.sqrt((640-center_x)**2 + (335-center_y)**2)
                if frame % 100 > 50 and frame % 100 <= 99:
                    points -= 5
                elif distance <= 80 and ufo_camera <= 100+start_radius:
                    points += 10
                elif distance <= 80 and ufo_camera > 100+start_radius:
                    points -= 5


        window.fill(BLACK)
        amount = 0
        frame += 1
        if start_radius<=100:
            start_radius += 0.5
        if start_radius >100:
            start_radius = 20
            start_radius -= 0.5
        draw_camera(window, WIDTH/2-1000/2, HEIGHT/2-550/2, 100+start_radius)
        camera_button = pygame.Rect(WIDTH/2-1000/2,HEIGHT/2-550/2,80,80)
        if frame % 100 == 0:
            y_coor = random.randrange(335-100-round(start_radius), 335+100+round(start_radius))
            if((start_radius+100)**2 - (y_coor-335) **2 > 0):
                x_min = -1 * math.sqrt((start_radius+100)**2 - (y_coor-335) **2) + 640
                x_max = math.sqrt((start_radius+100)**2 - (y_coor-335) **2) + 640
                x_coor = random.randrange(round(x_min + 1), round(x_max - 1))
                ufo_list.append([x_coor, y_coor])
        if len(ufo_list) != 0:
            if frame % 100 > 0 and frame % 100 < 50:
                window.blit(ufo_2, ufo_list[len(ufo_list)-1])
                rect_x, rect_y = ufo_list[len(ufo_list)-1]


        points_print = font_1.render(f"Your point right now is {points}", True, WHITE)
        window.blit(points_print, [10, 5])

        if points > 150:
            camera_part = False
            key_part = True

    if key_part:
        time += 1
        window.fill(BLACK)
        font_1 = pygame.font.SysFont("verdana", 30, False, True)
        congrat = font_1.render("Congratulations, you've completed the task in this room", True, WHITE)
        key_award = font_1.render("And you are awarded with one key!", True, WHITE)
        window.blit(congrat, [300, 200])
        window.blit(key_award, [300, 230])
        draw_key(window, 500, 400, LIGHT_YELLOW)
        window.blit(image, [-100, 10])
        if time == 300:
            room = 3

    pygame.display.flip()
    clock.tick(30)

pygame.quit()